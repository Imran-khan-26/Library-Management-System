Author: Imran Khan
Project: Library Management System

LMS Requirement
Project Name	Library Management System
Language Used	PHP5.6, PHP7.x
Database	MySQL 5.x
User Interface Design	HTML, AJAX,JQUERY,JAVASCRIPT
Web Browser	Mozilla, Google Chrome, IE8, OPERA
Software	XAMPP / Wamp / Mamp/ Lamp (anyone)

How to run this Library Management System Project

1. Download and Unzip file on your local system copy library.
2. Put library folder inside�root directory

Database Configuration

Open phpmyadmin
Create Database�library
Import database library.sql (available inside zip package)

For User

Open Your browser put inside browser �http://localhost/library�
Login Details for user:�
Username: test@gmail.com
Password: Test@123

For Admin Panel

Open Your browser put inside browser �http://localhost/library/admin�
Login Details for admin :�
Username: admin
Password:Test@123
